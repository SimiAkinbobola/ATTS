// AddCandidateModal.tsx

import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface AddCandidateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAddCandidate: (candidate: any) => void;
}

export default function AddCandidateModal({
  open,
  onOpenChange,
  onAddCandidate,
}: AddCandidateModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    experience: "",
    skillRating: "",
    location: "",
    education: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Create new candidate object
    const newCandidate = {
      ...formData,
      id: Date.now(),
      experience: Number(formData.experience) || 0,
      skillRating: Number(formData.skillRating) || 0,
    };
    onAddCandidate(newCandidate);

    // Clear form
    setFormData({
      name: "",
      role: "",
      experience: "",
      skillRating: "",
      location: "",
      education: "",
    });

    // Close modal
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Add New Candidate</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-4 mt-4">
          {/* Name */}
          <div>
            <label className="block mb-1 text-sm font-semibold">Name</label>
            <input
              type="text"
              name="name"
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none"
              required
              value={formData.name}
              onChange={handleChange}
            />
          </div>
          {/* Role */}
          <div>
            <label className="block mb-1 text-sm font-semibold">Role</label>
            <input
              type="text"
              name="role"
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none"
              required
              value={formData.role}
              onChange={handleChange}
            />
          </div>
          {/* Experience */}
          <div>
            <label className="block mb-1 text-sm font-semibold">
              Experience (years)
            </label>
            <input
              type="number"
              name="experience"
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none"
              required
              min="0"
              value={formData.experience}
              onChange={handleChange}
            />
          </div>
          {/* Skill Rating */}
          <div>
            <label className="block mb-1 text-sm font-semibold">
              Skill Rating (0-10)
            </label>
            <input
              type="number"
              name="skillRating"
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none"
              required
              min="0"
              max="10"
              step="0.1"
              value={formData.skillRating}
              onChange={handleChange}
            />
          </div>
          {/* Location */}
          <div>
            <label className="block mb-1 text-sm font-semibold">Location</label>
            <input
              type="text"
              name="location"
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none"
              required
              value={formData.location}
              onChange={handleChange}
            />
          </div>
          {/* Education */}
          <div>
            <label className="block mb-1 text-sm font-semibold">Education</label>
            <input
              type="text"
              name="education"
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none"
              value={formData.education}
              onChange={handleChange}
            />
          </div>

          <DialogFooter>
            <Button variant="secondary" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Add Candidate</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
