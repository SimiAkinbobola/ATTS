// data.ts

export const initialCandidates = [
  {
    id: 1,
    name: "Jane Doe",
    role: "Software Engineer",
    experience: 5,
    skillRating: 8.4,
    location: "New York, USA",
    education: "BS in Computer Science",
  },
  {
    id: 2,
    name: "John Smith",
    role: "Data Scientist",
    experience: 3,
    skillRating: 6.1,
    location: "Berlin, Germany",
    education: "MS in Data Science",
  },
  {
    id: 3,
    name: "Emily Johnson",
    role: "Product Manager",
    experience: 7,
    skillRating: 9.2,
    location: "London, UK",
    education: "MBA",
  },
  {
    id: 4,
    name: "Michael Brown",
    role: "Quality Assurance",
    experience: 2,
    skillRating: 4.9,
    location: "Sydney, Australia",
    education: "Diploma in Software Testing",
  },
  {
    id: 5,
    name: "Sophia Lee",
    role: "UX Designer",
    experience: 4,
    skillRating: 7.0,
    location: "Toronto, Canada",
    education: "BDes in Visual Communication",
  },
  {
    id: 6,
    name: "David Garcia",
    role: "DevOps Engineer",
    experience: 6,
    skillRating: 5.5,
    location: "Seattle, USA",
    education: "BS in Information Systems",
  },
  {
    id: 7,
    name: "Lisa Wang",
    role: "Data Analyst",
    experience: 1,
    skillRating: 3.8,
    location: "Singapore",
    education: "BS in Statistics",
  },
  {
    id: 8,
    name: "Carlos Silva",
    role: "Backend Engineer",
    experience: 4,
    skillRating: 7.9,
    location: "Sao Paulo, Brazil",
    education: "BS in Computer Engineering",
  },
];

// A small utility to categorize a candidate based on skill rating
export function classifyCandidate(skillRating: number): string {
  if (skillRating >= 8) {
    return "High Skilled";
  } else if (skillRating >= 5) {
    return "Average Skilled";
  } else {
    return "Needs Improvement";
  }
}
