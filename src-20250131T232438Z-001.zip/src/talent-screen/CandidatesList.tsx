// CandidatesList.tsx

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Search, Filter } from "lucide-react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { classifyCandidate } from "./data";

interface Candidate {
  id: number;
  name: string;
  role: string;
  experience: number;
  skillRating: number;
  location: string;
  education: string;
}

interface CandidatesListProps {
  candidates: Candidate[];
  onSelectCandidate: (candidate: Candidate) => void;
}

export default function CandidatesList({
  candidates,
  onSelectCandidate,
}: CandidatesListProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("All");

  const filteredCandidates = candidates.filter((candidate) => {
    const candidateClassification = classifyCandidate(candidate.skillRating);

    // Search filter
    const matchesSearch =
      candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.education.toLowerCase().includes(searchTerm.toLowerCase());

    // Classification filter
    const matchesFilter =
      filter === "All" || candidateClassification === filter;

    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-6">Candidate List</h1>
      </motion.div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 mb-6">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2 top-2 text-gray-400" size={20} />
          <input
            type="text"
            className="w-full pl-8 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
            placeholder="Search candidates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="relative w-full max-w-xs">
          <Filter className="absolute left-2 top-2 text-gray-400" size={20} />
          <select
            className="w-full pl-8 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 appearance-none"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="All">All</option>
            <option value="High Skilled">High Skilled</option>
            <option value="Average Skilled">Average Skilled</option>
            <option value="Needs Improvement">Needs Improvement</option>
          </select>
        </div>
      </div>

      {/* Candidate Cards */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {filteredCandidates.map((candidate) => {
          const candidateClassification = classifyCandidate(
            candidate.skillRating
          );
          return (
            <motion.div
              key={candidate.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card
                className="shadow-md hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => onSelectCandidate(candidate)}
              >
                <CardHeader>
                  <CardTitle className="text-xl font-bold">
                    {candidate.name}
                  </CardTitle>
                  <p className="text-sm text-gray-500">{candidate.role}</p>
                </CardHeader>
                <CardContent>
                  <p className="mb-1">
                    Experience: {candidate.experience} years
                  </p>
                  <p className="mb-1">Skill Rating: {candidate.skillRating}</p>
                  <p className="mb-1">Location: {candidate.location}</p>
                  <p className="mb-1">Education: {candidate.education}</p>
                  <p className="mt-2 font-semibold">
                    Classification: {candidateClassification}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
