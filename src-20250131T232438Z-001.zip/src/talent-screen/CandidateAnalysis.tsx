// CandidateAnalysis.tsx

import React from "react";
import { motion } from "framer-motion";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { classifyCandidate } from "./data";

interface Candidate {
  id: number;
  name: string;
  role: string;
  experience: number;
  skillRating: number;
  location: string;
  education: string;
}

interface CandidateAnalysisProps {
  candidate: Candidate | null;
  onBack: () => void;
}

export default function CandidateAnalysis({
  candidate,
  onBack,
}: CandidateAnalysisProps) {
  if (!candidate) {
    return null;
  }

  const candidateClassification = classifyCandidate(candidate.skillRating);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-6">Candidate Analysis</h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="max-w-2xl"
      >
        <Card className="shadow-md hover:shadow-xl transition-shadow">
          <CardHeader>
            <CardTitle className="text-xl font-bold">
              {candidate.name} ({candidate.role})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-1">Experience: {candidate.experience} years</p>
            <p className="mb-1">Skill Rating: {candidate.skillRating}</p>
            <p className="mb-1">Location: {candidate.location}</p>
            <p className="mb-1">Education: {candidate.education}</p>
            <p className="mt-2 font-semibold">
              Classification: {candidateClassification}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      <div className="mt-6">
        <Button variant="secondary" onClick={onBack}>
          Back to Candidates
        </Button>
      </div>
    </div>
  );
}
