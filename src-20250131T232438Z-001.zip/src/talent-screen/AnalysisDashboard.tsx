import React, { useMemo } from "react";
import { motion } from "framer-motion";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
} from "chart.js";
import { Bar, Line, Doughnut } from "react-chartjs-2";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { classifyCandidate } from "./data"; // or wherever you keep classifyCandidate
import type { Candidate } from "./types"; // your type definitions, if any

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

/**
 * Props:
 *  - candidates: The array of candidate objects
 *  - onBack: callback when user wants to return to a previous page
 */
interface AnalysisDashboardProps {
  candidates: Candidate[];
  onBack: () => void;
}

export default function AnalysisDashboard({
  candidates,
  onBack,
}: AnalysisDashboardProps) {
  // Compute some stats
  const stats = useMemo(() => {
    const total = candidates.length;
    let expSum = 0;
    let skillSum = 0;

    // Classification tallies
    let highCount = 0;
    let avgCount = 0;
    let needsCount = 0;

    candidates.forEach((c) => {
      expSum += c.experience;
      skillSum += c.skillRating;
      const classification = classifyCandidate(c.skillRating);
      if (classification === "High Skilled") highCount++;
      else if (classification === "Average Skilled") avgCount++;
      else needsCount++;
    });

    const avgExp = total > 0 ? expSum / total : 0;
    const avgSkill = total > 0 ? skillSum / total : 0;

    return {
      total,
      avgExp,
      avgSkill,
      highCount,
      avgCount,
      needsCount,
    };
  }, [candidates]);

  // ------------------------------------------------
  //  BAR CHART: Classification Distribution
  // ------------------------------------------------
  const barData = {
    labels: ["High Skilled", "Average Skilled", "Needs Improvement"],
    datasets: [
      {
        label: "Number of Candidates",
        data: [stats.highCount, stats.avgCount, stats.needsCount],
        backgroundColor: ["#4ade80", "#60a5fa", "#f87171"], // tailwind colors
      },
    ],
  };
  const barOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
    },
  };

  // ------------------------------------------------
  //  DOUGHNUT CHART: Candidate Location Breakdown
  // ------------------------------------------------
  // For demonstration, let's group by location quickly
  // e.g. count how many candidates are in each location
  const locationMap = useMemo(() => {
    const map: Record<string, number> = {};
    candidates.forEach((c) => {
      map[c.location] = (map[c.location] || 0) + 1;
    });
    return map;
  }, [candidates]);

  const doughnutData = {
    labels: Object.keys(locationMap),
    datasets: [
      {
        data: Object.values(locationMap),
        backgroundColor: [
          "#fbbf24",
          "#f472b6",
          "#34d399",
          "#60a5fa",
          "#c084fc",
          "#f87171",
          "#e879f9",
          "#facc15",
        ],
      },
    ],
  };

  // ------------------------------------------------
  //  LINE CHART: Skill Rating by Candidate
  // ------------------------------------------------
  // Sort by skill rating descending for a fun view
  const sortedCandidates = [...candidates].sort(
    (a, b) => b.skillRating - a.skillRating
  );
  const lineData = {
    labels: sortedCandidates.map((c) => c.name),
    datasets: [
      {
        label: "Skill Rating",
        data: sortedCandidates.map((c) => c.skillRating),
        borderColor: "#10b981",
        backgroundColor: "#6ee7b7",
      },
    ],
  };
  const lineOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: true,
      },
    },
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Page Title */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-6">Overall Analysis Dashboard</h1>
      </motion.div>

      {/* Summary Cards */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Total candidates */}
        <Card className="bg-blue-50 border border-blue-100">
          <CardHeader>
            <CardTitle className="text-blue-800">Total Candidates</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-700">{stats.total}</p>
          </CardContent>
        </Card>

        {/* Average Skill */}
        <Card className="bg-green-50 border border-green-100">
          <CardHeader>
            <CardTitle className="text-green-800">Average Skill</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-700">
              {stats.avgSkill.toFixed(1)}
            </p>
          </CardContent>
        </Card>

        {/* Average Experience */}
        <Card className="bg-yellow-50 border border-yellow-100">
          <CardHeader>
            <CardTitle className="text-yellow-800">Avg Experience</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-yellow-700">
              {stats.avgExp.toFixed(1)} yrs
            </p>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Classification Bar Chart */}
        <motion.div
          className="p-4 bg-white rounded-2xl shadow"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-lg font-semibold mb-2">Classification Distribution</h2>
          <Bar data={barData} options={barOptions} />
        </motion.div>

        {/* Location Breakdown (Doughnut) */}
        <motion.div
          className="p-4 bg-white rounded-2xl shadow"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-lg font-semibold mb-2">Location Breakdown</h2>
          <Doughnut data={doughnutData} />
        </motion.div>

        {/* Skill Rating by Candidate (Line) */}
        <motion.div
          className="p-4 bg-white rounded-2xl shadow lg:col-span-2"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-lg font-semibold mb-2">Skill Rating (Descending)</h2>
          <Line data={lineData} options={lineOptions} />
        </motion.div>
      </div>

      {/* Back Button */}
      <div className="mt-8">
        <Button variant="secondary" onClick={onBack}>
          Back
        </Button>
      </div>
    </div>
  );
}
