// AutomatedTalentScreen.tsx

import React, { useState } from "react";
import { PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import CandidatesList from "./CandidatesList";
import CandidateAnalysis from "./CandidateAnalysis";
import AddCandidateModal from "./AddCandidateModal";
import { initialCandidates } from "./data";

export default function AutomatedTalentScreen() {
  const [candidates, setCandidates] = useState(initialCandidates);
  const [selectedCandidate, setSelectedCandidate] = useState<any>(null);
  const [page, setPage] = useState<"list" | "analysis">("list");
  const [showAddModal, setShowAddModal] = useState(false);

  const handleSelectCandidate = (candidate: any) => {
    setSelectedCandidate(candidate);
    setPage("analysis");
  };

  const handleAddCandidate = (newCandidate: any) => {
    setCandidates((prev) => [...prev, newCandidate]);
  };

  if (page === "analysis" && selectedCandidate) {
    return (
      <CandidateAnalysis
        candidate={selectedCandidate}
        onBack={() => {
          setPage("list");
          setSelectedCandidate(null);
        }}
      />
    );
  }

  return (
    <div className="relative">
      {/* Candidates List Page */}
      <CandidatesList candidates={candidates} onSelectCandidate={handleSelectCandidate} />

      {/* Add New Candidate Floating Button */}
      <div className="fixed bottom-6 right-6">
        <Button onClick={() => setShowAddModal(true)} className="flex items-center space-x-2">
          <PlusCircle size={18} />
          <span>Add New Candidate</span>
        </Button>
      </div>

      {/* Add Candidate Modal */}
      <AddCandidateModal
        open={showAddModal}
        onOpenChange={setShowAddModal}
        onAddCandidate={handleAddCandidate}
      />
    </div>
  );
}
